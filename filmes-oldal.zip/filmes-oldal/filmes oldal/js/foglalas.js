const uploadButton = document.getElementById('uploadButton');
        uploadButton.addEventListener('click', () => {
            alert(`Sikeresen megvásárolta a jegyeit a filmre!!`);
        });